$('body').append(
  `	<div id="moldfy" class="classFy">
  <div  class="labelFy">
    <div  class="temFy">
     
      风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f2.moldWindPress +
    `Pa</div>
  </div>
</div>
	<div id="moldfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f2.moldBuffWindPress +
    `Pa</div>
</div>
</div>`
)

var moldfy = document.getElementById('moldfy')
var moldfy_hc = document.getElementById('moldfy_hc')

var moldfylabel = new CSS3DSprite(moldfy)
moldfylabel.name = 'moldfy'
var moldfy_hclabel = new CSS3DSprite(moldfy_hc)
moldfy_hclabel.name = 'mold_hcfy'
twofloorFy.add(moldfylabel)
twofloorFy_hc.add(moldfy_hclabel)

/**肠道 */

$('body').append(
  `	<div id="gutfy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f2.gutWindPress +
    `Pa</div>
</div>
</div>
<div id="gutfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f2.gutBuffWindPress +
    `Pa</div>
</div>
</div>`
)

var gutfy = document.getElementById('gutfy')
var gutfy_hc = document.getElementById('gutfy_hc')

var gutfylabel = new CSS3DSprite(gutfy)
gutfylabel.name = 'gutfy'
var gutfy_hclabel = new CSS3DSprite(gutfy_hc)
gutfy_hclabel.name = 'gut_hcfy'
twofloorFy.add(gutfylabel)
twofloorFy_hc.add(gutfy_hclabel)

$('body').append(
  `	<div id="rstfy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f2.rstWindPress +
    `Pa</div>
</div>
</div>
<div id="rstfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f2.rstBuffWindPress +
    `Pa</div>
</div>
</div>`
)

var rstfy = document.getElementById('rstfy')
var rstfy_hc = document.getElementById('rstfy_hc')

var rstfylabel = new CSS3DSprite(rstfy)
rstfylabel.name = 'rstfy'
var rstfy_hclabel = new CSS3DSprite(rstfy_hc)
rstfy_hclabel.name = 'rst_hcfy'
twofloorFy.add(rstfylabel)
twofloorFy_hc.add(rstfy_hclabel)

/**modbusBm2f4 */
/** 高致病*/
/** 高致病*/
$('body').append(
  `	<div id="gzbfy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f4.gzbfy +
    `Pa</div>
</div>
</div>
<div id="gzbfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f4.gzbhcfy +
    `Pa</div>
</div>
</div>`
)

var gzbfy = document.getElementById('gzbfy')
var gzbfy_hc = document.getElementById('gzbfy_hc')

var gzbfylabel = new CSS3DSprite(gzbfy)
gzbfylabel.name = 'gzbfy'
var gzbfy_hclabel = new CSS3DSprite(gzbfy_hc)
gzbfy_hclabel.name = 'gzb_hcfy'
twofloorFy.add(gzbfylabel)
twofloorFy_hc.add(gzbfy_hclabel)

/** 样本病*/
$('body').append(
  `	<div id="ybfy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f4.ybfy +
    `Pa</div>
</div>
</div>
<div id="ybfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f4.ybhcfy +
    `Pa</div>
</div>
</div>`
)

var ybfy = document.getElementById('ybfy')
var ybfy_hc = document.getElementById('ybfy_hc')

var ybfylabel = new CSS3DSprite(ybfy)
ybfylabel.name = 'ybfy'
var ybfy_hclabel = new CSS3DSprite(ybfy_hc)
ybfy_hclabel.name = 'yb_hcfy'
twofloorFy.add(ybfylabel)
twofloorFy_hc.add(ybfy_hclabel)

/** 试剂*/
$('body').append(
  `	<div id="sjfy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f4.sjfy +
    `Pa</div>
</div>
</div>
<div id="sjfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f4.sjhcfy +
    `Pa</div>
</div>
</div>`
)

var sjfy = document.getElementById('sjfy')
var sjfy_hc = document.getElementById('sjfy_hc')

var sjfylabel = new CSS3DSprite(sjfy)
sjfylabel.name = 'sjfy'
var sjfy_hclabel = new CSS3DSprite(sjfy_hc)
sjfy_hclabel.name = 'sj_hcfy'
twofloorFy.add(sjfylabel)
twofloorFy_hc.add(sjfy_hclabel)

/** 核酸*/
$('body').append(
  `	<div id="hsfy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f4.hsfy +
    `Pa</div>
</div>
</div>
<div id="hsfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f4.hshcfy +
    `Pa</div>
</div>
</div>`
)

var hsfy = document.getElementById('hsfy')
var hsfy_hc = document.getElementById('hsfy_hc')

var hsfylabel = new CSS3DSprite(hsfy)
hsfylabel.name = 'hsfy'
var hsfy_hclabel = new CSS3DSprite(hsfy_hc)
hsfy_hclabel.name = 'hs_hcfy'
twofloorFy.add(hsfylabel)
twofloorFy_hc.add(hsfy_hclabel)

/** 扩增分析*/
$('body').append(
  `	<div id="kzfxfy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f9.kzfxfy +
    `Pa</div>
</div>
</div>
<div id="kzfxfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f9.kzfxhcfy +
    `Pa</div>
</div>
</div>`
)

var kzfxfy = document.getElementById('kzfxfy')
var kzfxfy_hc = document.getElementById('kzfxfy_hc')

var kzfxfylabel = new CSS3DSprite(kzfxfy)
kzfxfylabel.name = 'kzfxfy'
var kzfxfy_hclabel = new CSS3DSprite(kzfxfy_hc)
kzfxfy_hclabel.name = 'kzfx_hcfy'
twofloorFy.add(kzfxfylabel)
twofloorFy_hc.add(kzfxfy_hclabel)

/** 产物分析*/
$('body').append(
  `	<div id="cwfxfy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f4.cwfxfy +
    `Pa</div>
</div>
</div>
<div id="cwfxfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f4.cwfxhcfy +
    `Pa</div>
</div>
</div>`
)

var cwfxfy = document.getElementById('cwfxfy')
var cwfxfy_hc = document.getElementById('cwfxfy_hc')

var cwfxfylabel = new CSS3DSprite(cwfxfy)
cwfxfylabel.name = 'cwfxfy'
var cwfxfy_hclabel = new CSS3DSprite(cwfxfy_hc)
cwfxfy_hclabel.name = 'cwfx_hcfy'
twofloorFy.add(cwfxfylabel)
twofloorFy_hc.add(cwfxfy_hclabel)

/**ModbusBms2f8 */
/** 产物*/

$('body').append(
  `	<div id="cwfy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.cwfy +
    `Pa</div>
</div>
</div>
<div id="cwfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.cwhcfy +
    `Pa</div>
</div>
</div>`
)

var cwfy = document.getElementById('cwfy')
var cwfy_hc = document.getElementById('cwfy_hc')

var cwfylabel = new CSS3DSprite(cwfy)
cwfylabel.name = 'cwfy'
var cwfy_hclabel = new CSS3DSprite(cwfy_hc)
cwfy_hclabel.name = 'cw_hcfy'
twofloorFy.add(cwfylabel)
twofloorFy_hc.add(cwfy_hclabel)

/** 致病菌*/
$('body').append(
  `	<div id="zbjfy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.zbjfy +
    `Pa</div>
</div>
</div>
<div id="zbjfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.zbjhcfy +
    `Pa</div>
</div>
</div>`
)

var zbjfy = document.getElementById('zbjfy')
var zbjfy_hc = document.getElementById('zbjfy_hc')

var zbjfylabel = new CSS3DSprite(zbjfy)
zbjfylabel.name = 'zbjfy'
var zbjfy_hclabel = new CSS3DSprite(zbjfy_hc)
zbjfy_hclabel.name = 'zbj_hcfy'
twofloorFy.add(zbjfylabel)
twofloorFy_hc.add(zbjfy_hclabel)
/** 扩增分析室*/
$('body').append(
  `	<div id="kzfy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.kzfy +
    `Pa</div>
</div>
</div>
<div id="kzfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.kzhcfy +
    `Pa</div>
</div>
</div>`
)

var kzfy = document.getElementById('kzfy')
var kzfy_hc = document.getElementById('kzfy_hc')

var kzfylabel = new CSS3DSprite(kzfy)
kzfylabel.name = 'kzfy'
var kzfy_hclabel = new CSS3DSprite(kzfy_hc)
kzfy_hclabel.name = 'kz_hcfy'
twofloorFy.add(kzfylabel)
twofloorFy_hc.add(kzfy_hclabel)

/** 样本1*/
$('body').append(
  `	<div id="yb1fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.ybfy1 +
    `Pa</div>
</div>
</div>
<div id="yb1fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.ybhcfy1 +
    `Pa</div>
</div>
</div>`
)

var ybfy = document.getElementById('ybfy')
var ybfy_hc = document.getElementById('ybfy_hc')

var ybfylabel = new CSS3DSprite(ybfy)
ybfylabel.name = 'yb1fy'
var ybfy_hclabel = new CSS3DSprite(ybfy_hc)
ybfy_hclabel.name = 'yb1_hcfy'
twofloorFy.add(ybfylabel)
twofloorFy_hc.add(ybfy_hclabel)
/** 样本2*/
$('body').append(
  `	<div id="yb2fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.ybfy2 +
    `Pa</div>
</div>
</div>
<div id="yb2fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.ybhcfy2 +
    `Pa</div>
</div>
</div>`
)

var ybfy = document.getElementById('yb2fy')
var ybfy_hc = document.getElementById('yb2fy_hc')

var ybfylabel = new CSS3DSprite(ybfy)
ybfylabel.name = 'yb2fy'
var ybfy_hclabel = new CSS3DSprite(ybfy_hc)
ybfy_hclabel.name = 'yb2_hcfy'
twofloorFy.add(ybfylabel)
twofloorFy_hc.add(ybfy_hclabel)

/** 试剂1*/
$('body').append(
  `	<div id="sjfy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.sjfy +
    `Pa</div>
</div>
</div>
<div id="sjfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.sjhcfy +
    `Pa</div>
</div>
</div>`
)

var sjfy = document.getElementById('sjfy')
var sjfy_hc = document.getElementById('sjfy_hc')

var sjfylabel = new CSS3DSprite(sjfy)
sjfylabel.name = 'sj1fy'
var sjfy_hclabel = new CSS3DSprite(sjfy_hc)
sjfy_hclabel.name = 'sj1_hcfy'
twofloorFy.add(sjfylabel)
twofloorFy_hc.add(sjfy_hclabel)

/** 试剂2*/
$('body').append(
  `	<div id="sj2fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.sjfy2 +
    `Pa</div>
</div>
</div>
<div id="sj2fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.sjhcfy2 +
    `Pa</div>
</div>
</div>`
)

var sj2fy = document.getElementById('sj2fy')
var sj2fy_hc = document.getElementById('sj2fy_hc')

var sj2fylabel = new CSS3DSprite(sj2fy)
sj2fylabel.name = 'sj2fy'
var sj2fy_hclabel = new CSS3DSprite(sj2fy_hc)
sj2fy_hclabel.name = 'sj2_hcfy'
twofloorFy.add(sj2fylabel)
twofloorFy_hc.add(sj2fy_hclabel)

/** 核酸*/

$('body').append(
  `	<div id="hs2fy" class="classFy">
  <div  class="labelFy">
    <div  class="temFy">
     
      风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.hsfy +
    `Pa</div>
  </div>
</div>
  <div id="hs2fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f8.hshcfy +
    `Pa</div>
</div>
</div>`
)

var hsfy = document.getElementById('hs2fy')
var hsfy_hc = document.getElementById('hs2fy_hc')

var hsfylabel = new CSS3DSprite(hsfy)
hsfylabel.name = 'hsbdfy'
var hsfy_hclabel = new CSS3DSprite(hsfy_hc)
hsfy_hclabel.name = 'hsbd_hcfy'
twofloorFy.add(hsfylabel)
twofloorFy_hc.add(hsfy_hclabel)
/**ModbusBms2f8 */
/** 呼吸道*/
$('body').append(
  `	<div id="wxd2fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f9.wxdfy +
    `Pa</div>
</div>
</div>
<div id="wxd2fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f9.wxdhcfy +
    `Pa</div>
</div>
</div>`
)

var wxd2fy = document.getElementById('wxd2fy')
var wxd2fy_hc = document.getElementById('wxd2fy_hc')

var wxd2fylabel = new CSS3DSprite(wxd2fy)
wxd2fylabel.name = 'wxd2fy'
var wxd2fy_hclabel = new CSS3DSprite(wxd2fy_hc)
wxd2fy_hclabel.name = 'wxd2_hcfy'
twofloorFy.add(wxd2fylabel)
twofloorFy_hc.add(wxd2fy_hclabel)

/** 肠道病毒*/
$('body').append(
  `	<div id="cd2fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f9.cdfy +
    `Pa</div>
</div>
</div>
<div id="cd2fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f9.cdhcfy +
    `Pa</div>
</div>
</div>`
)

var cd2fy = document.getElementById('cd2fy')
var cd2fy_hc = document.getElementById('cd2fy_hc')

var cd2fylabel = new CSS3DSprite(cd2fy)
cd2fylabel.name = 'cdfy'
var cd2fy_hclabel = new CSS3DSprite(cd2fy_hc)
cd2fy_hclabel.name = 'cd_hcfy'
twofloorFy.add(cd2fylabel)
twofloorFy_hc.add(cd2fy_hclabel)
/** 细胞培养1*/
$('body').append(
  `	<div id="xb1fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f9.xbfy1 +
    `Pa</div>
</div>
</div>
<div id="xb1fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f9.xbhcfy1 +
    `Pa</div>
</div>
</div>`
)

var xb1fy = document.getElementById('xb1fy')
var xb1fy_hc = document.getElementById('xb1fy_hc')

var xb1fylabel = new CSS3DSprite(xb1fy)
xb1fylabel.name = 'xb1fy'
var xb1fy_hclabel = new CSS3DSprite(xb1fy_hc)
xb1fy_hclabel.name = 'xb1_hcfy'
twofloorFy.add(xb1fylabel)
twofloorFy_hc.add(xb1fy_hclabel)
/** 细胞培养2*/
$('body').append(
  `	<div id="xb2fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f9.xbfy2 +
    `Pa</div>
</div>
</div>
<div id="xb2fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f9.xbhcfy2 +
    `Pa</div>
</div>
</div>`
)

var xb2fy = document.getElementById('xb2fy')
var xb2fy_hc = document.getElementById('xb2fy_hc')

var xb2fylabel = new CSS3DSprite(xb2fy)
xb2fylabel.name = 'xb2fy'
var xb2fy_hclabel = new CSS3DSprite(xb2fy_hc)
xb2fy_hclabel.name = 'xb2_hcfy'
twofloorFy.add(xb2fylabel)
twofloorFy_hc.add(xb2fy_hclabel)
/** 测序*/
$('body').append(
  `	<div id="cx2fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.cxfy +
    `Pa</div>
</div>
</div>
<div id="cx2fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.cxhcfy +
    `Pa</div>
</div>
</div>`
)

var cx2fy = document.getElementById('cx2fy')
var cx2fy_hc = document.getElementById('cx2fy_hc')

var cx2fylabel = new CSS3DSprite(cx2fy)
cx2fylabel.name = 'cxfy'
var cx2fy_hclabel = new CSS3DSprite(cx2fy_hc)
cx2fy_hclabel.name = 'cx_hcfy'
twofloorFy.add(cx2fylabel)
twofloorFy_hc.add(cx2fy_hclabel)

/** 扩增*/
$('body').append(
  `	<div id="kz2fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.kzfy +
    `Pa</div>
</div>
</div>
<div id="kz2fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.kzhcfy +
    `Pa</div>
</div>
</div>`
)

var kzfy = document.getElementById('kz2fy')
var kzfy_hc = document.getElementById('kz2fy_hc')

var kzfylabel = new CSS3DSprite(kzfy)
kzfylabel.name = 'kzndfy'
var kzfy_hclabel = new CSS3DSprite(kzfy_hc)
kzfy_hclabel.name = 'kznd_hcfy'
twofloorFy.add(kzfylabel)
twofloorFy_hc.add(kzfy_hclabel)

/** 数据*/
$('body').append(
  `	<div id="shujufy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.shujufy +
    `Pa</div>
</div>
</div>
<div id="shujufy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.shujuhcfy +
    `Pa</div>
</div>
</div>`
)

var shujufy = document.getElementById('shujufy')
var shujufy_hc = document.getElementById('shujufy_hc')

var shujufylabel = new CSS3DSprite(shujufy)
shujufylabel.name = 'shujufy'
var shujufy_hclabel = new CSS3DSprite(shujufy_hc)
shujufy_hclabel.name = 'shuju_hcfy'
twofloorFy.add(shujufylabel)
twofloorFy_hc.add(shujufy_hclabel)
/** 11-试剂*/
$('body').append(
  `	<div id="sjfynd" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.sjfy +
    `Pa</div>
</div>
</div>
<div id="sjfynd_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.sjhcfy +
    `Pa</div>
</div>
</div>`
)

var sjfynd = document.getElementById('sjfynd')
var sjfynd_hc = document.getElementById('sjfynd_hc')

var sjfyndlabel = new CSS3DSprite(sjfynd)
sjfyndlabel.name = 'sjndfy'
var sjfynd_hclabel = new CSS3DSprite(sjfynd_hc)
sjfynd_hclabel.name = 'sjnd_hcfy'
twofloorFy.add(sjfyndlabel)
twofloorFy_hc.add(sjfynd_hclabel)

/** 11-文库*/
$('body').append(
  `	<div id="fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.wkfy +
    `Pa</div>
</div>
</div>
<div id="wk2fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.wkhcfy +
    `Pa</div>
</div>
</div>`
)

var wk2fy = document.getElementById('wk2fy')
var wk2fy_hc = document.getElementById('wk2fy_hc')

var wk2fylabel = new CSS3DSprite(wk2fy)
wk2fylabel.name = 'wkfy'
var wk2fy_hclabel = new CSS3DSprite(wk2fy_hc)
wk2fy_hclabel.name = 'wk_hcfy'
twofloorFy.add(wk2fylabel)
twofloorFy_hc.add(wk2fy_hclabel)

/** 11 - 样本*/
$('body').append(
  `	<div id="ybndfy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.ybfy +
    `Pa</div>
</div>
</div>
<div id="ybndfy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.ybhcfy +
    `Pa</div>
</div>
</div>`
)

var ybndfy = document.getElementById('ybndfy')
var ybndfy_hc = document.getElementById('ybndfy_hc')

var ybndfylabel = new CSS3DSprite(ybndfy)
ybndfylabel.name = 'ybndfy'
var ybndfy_hclabel = new CSS3DSprite(ybndfy_hc)
ybndfy_hclabel.name = 'ybnd_hcfy'
twofloorFy.add(ybndfylabel)
twofloorFy_hc.add(ybndfy_hclabel)

/**12 -  多病原P2*/
$('body').append(
  `	<div id="dbyp2fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.dbyp2fy +
    `Pa</div>
</div>
</div>
<div id="dbyp2fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.dbyp2hcfy +
    `Pa</div>
</div>
</div>`
)

var dbyp2fy = document.getElementById('dbyp2fy')
var dbyp2fy_hc = document.getElementById('dbyp2fy_hc')

var dbyp2fylabel = new CSS3DSprite(dbyp2fy)
dbyp2fylabel.name = 'dbyp2fy'
var dbyp2fy_hclabel = new CSS3DSprite(dbyp2fy_hc)
dbyp2fy_hclabel.name = 'dbyp2_hcfy'
twofloorFy.add(dbyp2fylabel)
twofloorFy_hc.add(dbyp2fy_hclabel)

/**12 -  预留P2*/
/** 测序*/
$('body').append(
  `	<div id="ylp2fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f12.ylp2fy +
    `Pa</div>
</div>
</div>
<div id="ylp2fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f12.ylp2hcfy +
    `Pa</div>
</div>
</div>`
)

var ylp2fy = document.getElementById('ylp2fy')
var ylp2fy_hc = document.getElementById('ylp2fy_hc')

var ylp2fylabel = new CSS3DSprite(ylp2fy)
ylp2fylabel.name = 'ylp2fy'
var ylp2fy_hclabel = new CSS3DSprite(ylp2fy_hc)
ylp2fy_hclabel.name = 'ylp2_hcfy'
twofloorFy.add(ylp2fylabel)
twofloorFy_hc.add(ylp2fy_hclabel)

/** 13-洁净*/
$('body').append(
  `	<div id="jj1fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f13.jj1fy +
    `Pa</div>
</div>
</div>
<div id="jj1fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f13.jj1hcfy +
    `Pa</div>
</div>
</div>`
)

var jj1fy = document.getElementById('jj1fy')
var jj1fy_hc = document.getElementById('jj1fy_hc')

var jj1fylabel = new CSS3DSprite(jj1fy)
jj1fylabel.name = 'jj1fy'
var jj1fy_hclabel = new CSS3DSprite(jj1fy_hc)
jj1fy_hclabel.name = 'jj1_hcfy'
twofloorFy.add(jj1fylabel)
twofloorFy_hc.add(jj1fy_hclabel)

/** 洁净*/
$('body').append(
  `	<div id="jj2fy" class="classFy">
<div  class="labelFy">
  <div  class="temFy">
   
    风压差</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.jj2fy +
    `Pa</div>
</div>
</div>
<div id="jj2fy_hc" class="classFy">
<div  class="labelFy">
<div  class="temFy">缓冲风压</div>
<div  class="humFy">` +
    ModbusBmsvalue.ModbusBms2f11.jj2hcfy +
    `Pa</div>
</div>
</div>`
)

var jj2fy = document.getElementById('jj2fy')
var jj2fy_hc = document.getElementById('jj2fy_hc')

var jj2fylabel = new CSS3DSprite(jj2fy)
jj2fylabel.name = 'jj2fy'
var jj2fy_hclabel = new CSS3DSprite(jj2fy_hc)
jj2fy_hclabel.name = 'jj2_hcfy'
twofloorFy.add(jj2fylabel)
twofloorFy_hc.add(jj2fy_hclabel)
