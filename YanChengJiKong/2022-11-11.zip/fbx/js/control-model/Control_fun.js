import * as THREE from '../../../build/three.module.js'

import { scene, renderer, camera, labelRenderer } from './Control_scene.js'
import { CSS3DSprite } from '../../jsm/renderers/CSS3DRenderer.js'

import { FBXLoader } from '../../jsm/loaders/FBXLoader.js'

var PF_controllabel = true,
  KT_controllabel = true,
  BF_controllabel = true,
  PAU_4fcontrollabel = true,
  MAU_controllabel = true,
  PAU_controllabel = true,
  AHU_controllabel = true
$('#no').bind('hello', function () {
  console.log(document.getElementById('iframe'))
  document
    .getElementById('iframe')
    .removeChild(document.getElementById('iframe').childNodes[0])
  document.getElementById('iframe').style.visibility = 'hidden'
})
$('#PF_controllabel').click(function () {
  if (PF_controllabel == true) {
    PF_controllabel = false
    addBFData('3F_PF')
  } else {
    PF_controllabel = true
    meshLabel.element.style.visibility = 'hidden'
  }
})
$('#KT_controllabel').click(function () {
  if (KT_controllabel == true) {
    KT_controllabel = false
    addBFData('3F_AHU')
  } else {
    KT_controllabel = true
    meshLabel.element.style.visibility = 'hidden'
  }
})
$('#BF_controllabel').click(function () {
  if (BF_controllabel == true) {
    BF_controllabel = false
    addBFData('3F_BF')
  } else {
    BF_controllabel = true
    meshLabel.element.style.visibility = 'hidden'
  }
})
$('#PAU_4fcontrollabel').click(function () {
  if (PAU_4fcontrollabel == true) {
    PAU_4fcontrollabel = false
    hiddenAllMesh('3F_Layout')
    ShowFourMesh('4F_Layout')
    addBFData('4F_pau')
  } else {
    PAU_4fcontrollabel = true
    hiddenAllMesh('4F_Layout')
    ShowFourMesh('3F_Layout')
    meshLabel.element.style.visibility = 'hidden'
  }
})
$('#AHU_controllabel').click(function () {
  if (AHU_controllabel == true) {
    AHU_controllabel = false
    addAHUImg('2F_AHU', 'AHU.png')
  } else {
    AHU_controllabel = true
    deleteImg('2F_AHU')
  }
})

$('#MAU_controllabel').click(function () {
  if (MAU_controllabel == true) {
    MAU_controllabel = false
    addAHUImg('2F_MAU', 'MAU.png')
  } else {
    MAU_controllabel = true
    deleteImg('2F_MAU')
  }
})
$('#PAU_controllabel').click(function () {
  if (PAU_controllabel == true) {
    PAU_controllabel = false
    addBFImg('2F_PAU', 'PAU.png')
  } else {
    PAU_controllabel = true
    deleteImg('2F_PAU')
  }
})

// scene.add(TFGlabel)
/**添加四层模型 */
function ShowFourMesh(name) {
  scene.getChildByName(name).visible = true
}

function hiddenAllMesh(name) {
  scene.getObjectByName(name).visible = false
}

var PrimaryMesh = [],
  granaryArr = []
function AddMeshIntoArr(mesh, Arr) {
  var AArr
  if (Arr == 'granaryArr') {
    AArr = granaryArr
  } else if (Arr == 'PrimaryMesh') {
    AArr = PrimaryMesh
  }
  var device = scene.getObjectByName(mesh)
  console.log('device: ', device)
  device.traverse(function (obj) {
    if (obj.isMesh) {
      AArr.push(obj)
    }
  })
}
var changecolorMesh, PrimaryMesh

function pointermove(event) {
  if (changecolorMesh) {
    changecolorMesh.material.opacity = 0
    changecolorMesh.material.color.set(0xffffff)
  }

  var Sx = event.clientX //鼠标单击位置横坐标
  var Sy = event.clientY //鼠标单击位置纵坐标
  //屏幕坐标转WebGL标准设备坐标
  var x = (Sx / window.innerWidth) * 2 - 1 //WebGL标准设备横坐标
  var y = -(Sy / window.innerHeight) * 2 + 1 //WebGL标准设备纵坐标
  //创建一个射线投射器`Raycaster`
  var raycaster = new THREE.Raycaster()
  //通过鼠标单击位置标准设备坐标和相机参数计算射线投射器`Raycaster`的射线属性.ray
  raycaster.setFromCamera(new THREE.Vector2(x, y), camera)
  //返回.intersectObjects()参数中射线选中的网格模型对象
  // 未选中对象返回空数组[],选中一个数组1个元素，选中两个数组两个元素
  var intersects = raycaster.intersectObjects(PrimaryMesh)

  //   intersects.length大于0说明，说明选中了模型
  if (intersects.length > 0) {
    changecolorMesh = intersects[0].object
    // console.log('changecolorMesh: ', changecolorMesh)

    if (changecolorMesh.parent.name == 'Preselection') {
      changecolorMesh.material.opacity = 0.5
      changecolorMesh.material.color.set(0x33ffff)
    } else if (changecolorMesh.parent.name == '3F_Camera') {
      changecolorMesh.material.color.set(0x444444)
    }
  }
}

addEventListener('pointermove', pointermove)

var chooseMesh = null,
  chooseMeshemssive

/**单击选择模型 */
function choose(event) {
  if (chooseMesh) {
    chooseMesh.material.color.set(0x00ff00)
  } else if (chooseMesh) {
    label.element.style.visibility = 'hidden'
  }
  var Sx = event.clientX //鼠标单击位置横坐标
  var Sy = event.clientY //鼠标单击位置纵坐标
  //屏幕坐标转WebGL标准设备坐标
  var x = (Sx / window.innerWidth) * 2 - 1 //WebGL标准设备横坐标
  var y = -(Sy / window.innerHeight) * 2 + 1 //WebGL标准设备纵坐标
  //创建一个射线投射器`Raycaster`
  var raycaster = new THREE.Raycaster()
  //通过鼠标单击位置标准设备坐标和相机参数计算射线投射器`Raycaster`的射线属性.ray
  raycaster.setFromCamera(new THREE.Vector2(x, y), camera)
  //返回.intersectObjects()参数中射线选中的网格模型对象
  // 未选中对象返回空数组[],选中一个数组1个元素，选中两个数组两个元素
  var intersects = raycaster.intersectObjects(granaryArr)

  //console.log("射线投射器返回的对象 点point", intersects[0].point);
  if (intersects.length > 0) {
    chooseMesh = intersects[0].object
    console.log('chooseMesh: ', chooseMesh)

    ShowSystemLabel(chooseMesh.name)
  }
}
addEventListener('click', choose) // 监听窗口鼠标单击事件

function ShowSystemLabel(name) {
  console.log(name)
  $('#iframe').html('')
  $('#iframe').append(
    `  <iframe 
    src="./control-system/` +
      name +
      `.html"
    style="width: 1000px; height: 720px"
    frameborder="0"
  ></iframe>`
  )
  container2.style.visibility = 'visible'
}
var container2 = document.getElementById('iframe')
var TFGlabel = new CSS3DSprite(container2)
TFGlabel.name = 'iframelabel'

/*添加排风扇图标并判断开关状态 */
var ChineseName, modbusBmsvalue, ModbusBms_Startindex

function AcctiveAllDATA(meshname) {
  var jsonurl
  if (meshname == '3F_PF') {
    jsonurl = '././json/ModbusBms_startindex_PF.json'
  } else if (meshname == '3F_BF') {
    jsonurl = '././json/ModbusVav_startindex.json'
  } else if (meshname == '4F_pau' || meshname == '3F_AHU') {
    jsonurl = '././json/ModbusBms2F_startindex.json'
  }
  $.ajax({
    type: 'get',
    url: jsonurl,
    data: ModbusBms_Startindex,
    dataType: 'json',
    async: false, //默认为true 异步
    success: function (data) {
      ModbusBms_Startindex = data
    },
  })

  $.ajax({
    type: 'get',
    url: 'http://221.6.30.202:15007/prod-api/modbus/api/getNewestData?modbusType',
    data: modbusBmsvalue,
    dataType: 'json',
    async: false, //默认为true 异步
    success: function (data) {
      modbusBmsvalue = data.data
    },
  })
  // console.log('modbusBmsvalue: ', modbusBmsvalue)
  $.ajax({
    type: 'get',
    url: 'http://221.6.30.202:15007/prod-api/modbus/api/getFieldDetails?modbusType',
    data: ChineseName,
    dataType: 'json',
    async: false, //默认为true 异步
    success: function (data) {
      ChineseName = data.data
    },
  })
}

// function addImg(meshname, picture) {
//   $.ajax({
//     type: 'get',
//     url: 'http://221.6.30.202:15007/prod-api/modbus/api/getNewestData?modbusType',
//     data: modbusBmsvalue,
//     dataType: 'json',
//     async: false, //默认为true 异步
//     success: function (data) {
//       modbusBmsvalue = data.data
//     },
//   })
//   // console.log('modbusBmsvalue: ', modbusBmsvalue)
//   $.ajax({
//     type: 'get',
//     url: 'http://221.6.30.202:15007/prod-api/modbus/api/getFieldDetails?modbusType',
//     data: ChineseName,
//     dataType: 'json',
//     async: false, //默认为true 异步
//     success: function (data) {
//       ChineseName = data.data
//     },
//   })
//   $.ajax({
//     type: 'get',
//     url: '././json/ModbusBms_startindex_PF.json',
//     data: ModbusBms_Startindex,
//     dataType: 'json',
//     async: false, //默认为true 异步
//     success: function (data) {
//       ModbusBms_Startindex = data
//     },
//   })

//   console.log('ChineseName: ', ModbusBms_Startindex)

//   var Camera = scene.getObjectByName(meshname)
//   Camera.traverse(function (mesh) {
//     if (mesh.name.search('ModbusBms') < 0 && mesh.name != '3F_PF') {
//       $('body').append(
//         `<div id = "` +
//           mesh.name +
//           `">    <img id = "` +
//           mesh.name +
//           `rt"  class = "dingwei_img"   src = "././img/ControlImg/排风扇.png"  >
//           <div class="label_style"><input id="cbCheck` +
//           mesh.name +
//           `" class="btn-switch large" type="checkbox" value="1" checked="false"></div></div>
//           </div>`
//       )

//       for (const i in ChineseName[mesh.parent.name]) {
//         var chineseData = ChineseName[mesh.parent.name][i]

//         var Startindex = ModbusBms_Startindex[mesh.parent.name][mesh.name] - 1
//         if (
//           chineseData.search(mesh.name) >= 0 &&
//           (chineseData.search(mesh.name + '启停') >= 0 ||
//             chineseData.search(mesh.name + '运行') >= 0)
//         ) {
//           if (modbusBmsvalue[mesh.parent.name][i] == 1) {
//             $('#' + 'cbCheck' + mesh.name).prop('checked', true)
//           } else {
//             $('#' + 'cbCheck' + mesh.name).prop('checked', false)
//           }
//         }
//       }
//       $('#' + 'cbCheck' + mesh.name).change(function () {
//         var checkstatu = $('#' + 'cbCheck' + mesh.name).prop('checked')
//         var stuts = checkstatu == true ? 1 : 0

//         console.log(
//           `http://192.168.1.6:9007/prod-api/modbusWrite/api/writeModbus?modbusType=` +
//             mesh.parent.name +
//             `&setValue=` +
//             stuts +
//             `&startIndex=` +
//             Startindex +
//             `&setType=2`
//         )
//         $.ajax({
//           type: 'post',
//           url:
//             `http://192.168.1.6:9007/prod-api/modbusWrite/api/writeModbus?modbusType=` +
//             mesh.parent.name +
//             `&setValue=` +
//             stuts +
//             `&startIndex=` +
//             Startindex +
//             `&setType=2`,
//           data: ChineseName,
//           dataType: 'json',
//           async: false, //默认为true 异步
//           success: function (data) {
//             ChineseName = data.data
//           },
//         })
//       })
//       var tag = document.getElementById(mesh.name)
//       var meshLabel = new CSS3DSprite(tag)
//       meshLabel.name = mesh.name + 'n'
//       meshLabel.position.copy(mesh.getWorldPosition())
//       meshLabel.element.style.visibility = 'visible'

//       meshLabel.scale.set(0.14, 0.14, 0.14)

//       scene.add(meshLabel)

//       tag.onpointermove = function () {
//         scene.getObjectByName(mesh.name + 'n').scale.set(0.15, 0.15, 0.15)
//       }
//       tag.onpointerleave = function () {
//         scene.getObjectByName(mesh.name + 'n').scale.set(0.14, 0.14, 0.14)
//       }
//     }
//   })
// }

var tag = document.getElementById('table')
var meshLabel = new CSS3DSprite(tag)
meshLabel.scale.set(0.1, 0.1, 0.1)
// scene.add(meshLabel)
function addBFData(meshname) {
  AcctiveAllDATA(meshname)
  var Camera = scene.getObjectByName(meshname)
  $('#table').html('')
  $('#table').append(
    `
     <table   id="tableTH" class="tableTH_class"    border=1 width=500 height=100>
      </table>
        `
  )
  $('#tableTH').append(`<th>设备</th>
  <th>温度</th>
  <th>湿度</th>
  <th>开关</th>`)
  Camera.traverse(function (mesh) {
    if (
      mesh.name.search('ModbusVav') < 0 &&
      mesh.name.search('ModbusB') < 0 &&
      mesh.name != '3F_BF' &&
      mesh.name != '3F_PF' &&
      mesh.name != '2F_PAU' &&
      mesh.name != '3F_AHU' &&
      mesh.name != '4F_pau'
    ) {
      $('#tableTH').append(
        `
        <tr>
        <td>` +
          mesh.name +
          `</td>
          
        <td id="td_t` +
          mesh.name +
          `" class="td_TH"></td>
        <td id="td_h` +
          mesh.name +
          `"   class="td_TH"></td>
        <td><input id="cbCheck` +
          mesh.name +
          `" class="btn-switch large" type="checkbox" value="1" checked="false"></td>
      </tr>
            `
      )

      /**声明遍历对象子对象和最后传参 */
      var ModbusBms,
        Startindex,
        tempvalue,
        humvalue,
        meshNAme = mesh.name
      if (meshname == '3F_BF' || meshname == '3F_PF') {
        ModbusBms = mesh.parent.name
      } else if (meshname == '2F_PAU') {
        ModbusBms = mesh.name.slice(0, 12)
        meshNAme = '系统'
      } else if (meshname == '3F_AHU') {
        ModbusBms = mesh.name == 'AHU-3-2' ? 'ModbusBms3f7' : 'ModbusBms3f5'
        meshNAme = '设定'
      } else if (meshname == '4F_pau') {
        switch (mesh.name) {
          case 'PAU3-1':
            ModbusBms = 'ModbusBms3f1'
            break
          case 'PAU3-2':
            ModbusBms = 'ModbusBms3f2'
            break
          case 'PAU3-3':
            ModbusBms = 'ModbusBms3f3'
            break

          case 'PAU3-4':
            ModbusBms = 'ModbusBms3f4'
            break
        }
        meshNAme = '设定'
      }

      for (const i in ChineseName[ModbusBms]) {
        var chineseData = ChineseName[ModbusBms][i]
        // Startindex = ModbusVav_Startindex[ModbusBms][mesh.name] - 1
        /**筛选符合该模型名字的字段*/

        if (
          chineseData.search(meshNAme) >= 0 &&
          (chineseData.search(meshNAme + '启停') >= 0 ||
            chineseData.search(meshNAme + '运行') >= 0)
        ) {
          if (modbusBmsvalue[ModbusBms][i] == 1) {
            $('#' + 'cbCheck' + mesh.name).prop('checked', true)
          } else {
            $('#' + 'cbCheck' + mesh.name).prop('checked', false)
          }
        } else if (
          chineseData.search('读') >= 0 &&
          chineseData.search(meshNAme) >= 0 &&
          chineseData.search('设定温度') >= 0 &&
          chineseData.search('BF2-2') < 0
        ) {
          tempvalue = modbusBmsvalue[ModbusBms][i]

          $('#' + 'td_t' + mesh.name).append(
            `
          <div><div  id="` +
              'BF_temp' +
              mesh.name +
              `"   class="table_temp">` +
              modbusBmsvalue[ModbusBms][i] +
              `</div><div class="unit_t">℃</div>
              <div  id= "` +
              mesh.name +
              `tn">
		<input class="AHU_temp_input"  id ="` +
              mesh.name +
              `temprange"  type="range" min="15" max="40" step="1" value="` +
              modbusBmsvalue[ModbusBms][i] +
              `">
      </div>
              </div>
          
          `
          )
          addexcise(mesh, tempvalue, meshname)
        } else if (
          chineseData.search('读') >= 0 &&
          chineseData.search(meshNAme) >= 0 &&
          chineseData.search('湿度') >= 0
        ) {
          humvalue = modbusBmsvalue[ModbusBms][i]
          $('#' + 'td_h' + mesh.name).append(
            `<div><div  id="BF_hum` +
              mesh.name +
              `"   class="table_hum"> ` +
              modbusBmsvalue[ModbusBms][i] +
              `</div><div class="unit_h">%</div>
              
              <div  id= "` +
              mesh.name +
              `hn">
		<input class="AHU_hum_input"  id ="` +
              mesh.name +
              `humrange"  type="range" min="0" max="100" step="1" value="` +
              modbusBmsvalue[ModbusBms][i] +
              `">
      </div>
              </div>
          `
          )
          addHUmexcise(mesh, humvalue, meshname)
        }
      }
      $('#' + 'cbCheck' + mesh.name).change(function () {
        var checkstatu = $('#' + 'cbCheck' + mesh.name).prop('checked')
        var stuts = checkstatu == true ? 1 : 0

        console.log('ModbusBms_Startindex: ', ModbusBms_Startindex)
        Startindex = ModbusBms_Startindex[ModbusBms][mesh.name]

        console.log(
          `http://192.168.1.6:9007/prod-api/modbusWrite/api/writeModbus?modbusType=` +
            ModbusBms +
            `&setValue=` +
            stuts +
            `&startIndex=` +
            Startindex +
            `&setType=2`
        )

        $.ajax({
          type: 'post',
          url:
            `http://192.168.1.6:9007/prod-api/modbusWrite/api/writeModbus?modbusType=` +
            ModbusBms +
            `&setValue=` +
            stuts +
            `&startIndex=` +
            Startindex +
            `&setType=2`,
          data: ChineseName,
          dataType: 'json',
          async: false, //默认为true 异步
          success: function (data) {
            ChineseName = data.data
          },
        })
      })

      // })

      //绑定input监听事件
    }
  })
  meshLabel.element.style.visibility = 'visible'
}

function addexcise(mesh, tempvalue, meshname) {
  var name = mesh.name
  var elem = document.getElementById(name + 'temprange')

  //获取一个想显示值的标签，并且初始化默认值
  var target = document.getElementById('BF_temp' + name)

  // target.innerHTML = tempvalue

  var rangeValue = function () {
    var newValue = elem.value
    target.innerHTML = newValue
  }

  /**防止错误修改，添加确定按钮 */
  elem.onmouseup = function () {
    if (confirm('确定修改？')) {
      // if (tempvalue == elem.value) {
      //   alert('值未变')
      // }
      tempvalue = elem.value
      /**确定后发送修改数值 */

      changeTempData(tempvalue, mesh, meshname)
    } else {
      target.innerHTML = tempvalue
      elem.value = tempvalue
    }
  }

  //绑定input监听事件

  elem.addEventListener('input', rangeValue)
}
function addHUmexcise(mesh, humvalue, meshname) {
  var name = mesh.name
  var humelem = document.getElementById(name + 'humrange')

  //获取一个想显示值的标签，并且初始化默认值
  var humtarget = document.getElementById('BF_hum' + name)

  humtarget.innerHTML = humvalue

  var humrangeValue = function () {
    var newValue = humelem.value
    humtarget.innerHTML = newValue
  }

  /**防止错误修改，添加确定按钮 */
  humelem.onmouseup = function () {
    if (confirm('确定修改？')) {
      // if (tempvalue == elem.value) {
      //   alert('值未变')
      // }
      humvalue = humelem.value

      /**确定后发送修改数值 */
      changeTempData(humvalue, mesh, meshname)
    } else {
      humtarget.innerHTML = humvalue
      humelem.value = humvalue
    }
  }

  //绑定input监听事件

  humelem.addEventListener('input', humrangeValue)
}

// function deleteImg(meshname) {
//   var Camera = scene.getObjectByName(meshname)
//   Camera.traverse(function (mesh) {
//     var CameraImgLabel = scene.getObjectByName(mesh.name + 'n')
//     if (CameraImgLabel) CameraImgLabel.parent.remove(CameraImgLabel)
//     if (meshname == '3F_BF' || meshname == '2F_PAU' || meshname == '4F_PAU') {
//       var CameraImgLabel = scene.getObjectByName(mesh.name + 'hnn')
//       if (CameraImgLabel) CameraImgLabel.parent.remove(CameraImgLabel)
//     } else if (
//       meshname == '3F_AHU' ||
//       meshname == '2F_MAU' ||
//       meshname == '3F_AHU'
//     ) {
//       var temLanel = scene.getObjectByName(mesh.name + 'hnn')

//       if (temLanel) temLanel.parent.remove(temLanel)
//       var humLabel = scene.getObjectByName(mesh.name + 'HUMhnn')

//       if (humLabel) humLabel.parent.remove(humLabel)
//     }
//   })
// }

// function addchangTemptrue(name, mesh, meshname) {
//   var tempvalue = $('#' + 'BF' + mesh.name).text()
//   console.log('tempvalue: ', tempvalue)

//   $('body').append(
//     `
// 	  <div  id= "` +
//       name +
//       `hn">
// 		<input class="AHU_BF_input"  id ="` +
//       name +
//       `range"  type="range" min="15" max="40" step="1" value="` +
//       tempvalue +
//       `">
//       </div>
// `
//   )

//   var elem = document.getElementById(name + 'range')
//   console.log('elem: ', elem)

//   //获取一个想显示值的标签，并且初始化默认值
//   var target = document.getElementById('BF' + mesh.name)
//   console.log('target: ', target)
//   target.innerHTML = tempvalue

//   var rangeValue = function () {
//     var newValue = elem.value
//     target.innerHTML = newValue
//   }

//   /**防止错误修改，添加确定按钮 */
//   elem.onmouseup = function () {
//     if (confirm('确定修改？')) {
//       // if (tempvalue == elem.value) {
//       //   alert('值未变')
//       // }
//       tempvalue = elem.value

//       if (controlLabel) controlLabel.parent.remove(controlLabel)

//       /**确定后发送修改数值 */

//       changeTempData(tempvalue, mesh, meshname)
//     } else {
//       target.innerHTML = tempvalue
//       elem.value = tempvalue
//     }
//   }

//   //绑定input监听事件

//   elem.addEventListener('input', rangeValue)

//   var tag = document.getElementById(name + 'hn')
//   var controlLabel = new CSS3DSprite(tag)
//   controlLabel.name = name + 'hnn'
//   controlLabel.position.copy(mesh.getWorldPosition())
//   controlLabel.position.z += 10
//   controlLabel.scale.set(0.1, 0.1, 0.1)
//   scene.add(controlLabel)
// }

// /**设置空调的温度方法 */
// function addchangdata(name, mesh, meshname) {
//   var tempvalue = $('#' + 'temp' + mesh.name).text()
//   console.log('tempvalue: ', tempvalue)

//   $('body').append(
//     `
// 	  <div  id= "` +
//       name +
//       `hn">
// 		<input class="AHU_temp_input"  id ="` +
//       name +
//       `range"  type="range" min="15" max="40" step="1" value="` +
//       tempvalue +
//       `">
//       </div>
// `
//   )

//   var elem = document.getElementById(name + 'range')
//   console.log('elem: ', elem)

//   //获取一个想显示值的标签，并且初始化默认值
//   var target = document.getElementById('temp' + mesh.name)
//   console.log('target: ', target)
//   target.innerHTML = tempvalue

//   var rangeValue = function () {
//     var newValue = elem.value
//     target.innerHTML = newValue
//   }

//   /**防止错误修改，添加确定按钮 */
//   elem.onmouseup = function () {
//     if (confirm('确定修改？')) {
//       // if (tempvalue == elem.value) {
//       //   alert('值未变')
//       // }
//       tempvalue = elem.value

//       if (controlLabel) controlLabel.parent.remove(controlLabel)

//       /**确定后发送修改数值 */
//       changeTempData(tempvalue, mesh, meshname)
//     } else {
//       target.innerHTML = tempvalue
//       elem.value = tempvalue
//     }
//   }

//   //绑定input监听事件

//   elem.addEventListener('input', rangeValue)

//   var tag = document.getElementById(name + 'hn')
//   var controlLabel = new CSS3DSprite(tag)
//   controlLabel.name = name + 'hnn'
//   controlLabel.position.copy(mesh.getWorldPosition())
//   controlLabel.position.z += 0.5
//   controlLabel.scale.set(0.1, 0.1, 0.1)
//   scene.add(controlLabel)
// }
// /**设置空调的湿度方法 */
// function addHUMdata(name, mesh, meshname) {
//   var tempvalue = $('#' + 'hum' + mesh.name).text()
//   console.log('tempvalue: ', tempvalue)

//   $('body').append(
//     `
// 	  <div  id= "` +
//       name +
//       `HUMhn">
// 		<input class="AHU_hum_input"  id ="` +
//       name +
//       `HUMhnrange"  type="range" min="0" max="100" step="1" value="` +
//       tempvalue +
//       `">
//       </div>
// `
//   )

//   var elem = document.getElementById(name + 'HUMhnrange')
//   console.log('elem: ', elem)

//   //获取一个想显示值的标签，并且初始化默认值
//   var target = document.getElementById('hum' + mesh.name)
//   console.log('target: ', target)
//   target.innerHTML = tempvalue

//   var rangeValue = function () {
//     var newValue = elem.value
//     target.innerHTML = newValue
//   }

//   /**防止错误修改，添加确定按钮 */
//   elem.onmouseup = function () {
//     if (confirm('确定修改？')) {
//       // if (tempvalue == elem.value) {
//       //   alert('值未变')
//       // }
//       tempvalue = elem.value

//       if (controlLabel) controlLabel.parent.remove(controlLabel)

//       /**确定后发送修改数值 */
//       changeHumData(tempvalue, mesh, meshname)
//     } else {
//       target.innerHTML = tempvalue
//       elem.value = tempvalue
//     }
//   }

//   //绑定input监听事件

//   elem.addEventListener('input', rangeValue)

//   var tag = document.getElementById(name + 'HUMhn')
//   var controlLabel = new CSS3DSprite(tag)
//   controlLabel.name = name + 'HUMhnn'
//   controlLabel.position.copy(mesh.getWorldPosition())
//   controlLabel.position.z += 6.5
//   controlLabel.scale.set(0.1, 0.1, 0.1)
//   scene.add(controlLabel)
// }

/**提交温度修改 */
var ModbusBms_temp_startindex
function changeTempData(tempvalue, mesh, meshname) {
  console.log(meshname)
  var TempUrl, item
  if (meshname == '3F_BF') {
    item = mesh.parent.name
    TempUrl = '././json/ModbusVav_temp_startindex.json'
  } else if (meshname == '2F_MAU' || meshname == '2F_AHU') {
    item = mesh.name.slice(0, mesh.name.length - 9)
    TempUrl = '././json/ModbusBms_temp_startindex.json'
  } else if (meshname == '3F_AHU') {
    item = mesh.name == 'AHU-3-2' ? 'ModbusBms3f7' : 'ModbusBms3f5'
    TempUrl = '././json/ModbusBms_temp_startindex.json'
  } else if (meshname == '4F_pau') {
    switch (mesh.name) {
      case 'PAU3-1':
        item = 'ModbusBms3f1'
        break
      case 'PAU3-2':
        item = 'ModbusBms3f2'
        break
      case 'PAU3-3':
        item = 'ModbusBms3f3'
        break

      case 'PAU3-4':
        item = 'ModbusBms3f4'
        break
    }
    TempUrl = '././json/ModbusBms_temp_startindex.json'
  }
  /**查找对应接口 */
  $.ajax({
    type: 'get',
    url: TempUrl,
    data: ModbusBms_temp_startindex,
    dataType: 'json',
    async: false, //默认为true 异步
    success: function (data) {
      ModbusBms_temp_startindex = data
    },
  })
  console.log('item: ', item)
  console.log(ModbusBms_temp_startindex)
  var Startindex = ModbusBms_temp_startindex[item][mesh.name] - 1

  console.log(
    `http://192.168.1.6:9007/prod-api/modbusWrite/api/writeModbus?modbusType=` +
      item +
      `&setValue=` +
      tempvalue +
      `&startIndex=` +
      Startindex +
      `&setType=1`
  )
  /**带值发送请求 */
  $.ajax({
    type: 'post',
    url:
      `http://192.168.1.6:9007/prod-api/modbusWrite/api/writeModbus?modbusType=` +
      item +
      `&setValue=` +
      tempvalue +
      `&startIndex=` +
      Startindex +
      `&setType=1`,
    data: ChineseName,
    dataType: 'json',
    async: false, //默认为true 异步
    success: function (data) {
      ChineseName = data.data
    },
  })
}

/**提交湿度修改数据 */
var ModbusBms_hum_startindex
function changeHumData(tempvalue, mesh, meshname) {
  console.log(meshname)
  var TempUrl, item
  if (meshname == '2F_MAU' || meshname == '2F_AHU') {
    item = mesh.name.slice(0, mesh.name.length - 9)
  } else if (meshname == '3F_AHU') {
    item = mesh.name == 'AHU-3-2' ? 'ModbusBms3f7' : 'ModbusBms3f5'
  }

  /**查找对应接口 */
  $.ajax({
    type: 'get',
    url: '././json/ModbusBms_hum_startindex.json',
    data: ModbusBms_hum_startindex,
    dataType: 'json',
    async: false, //默认为true 异步
    success: function (data) {
      ModbusBms_hum_startindex = data
    },
  })
  console.log('item: ', item)

  var Startindex = ModbusBms_hum_startindex[item][mesh.name] - 1

  console.log(
    `http://192.168.1.6:9007/prod-api/modbusWrite/api/writeModbus?modbusType=` +
      item +
      `&setValue=` +
      tempvalue +
      `&startIndex=` +
      Startindex +
      `&setType=1`
  )
  /**带值发送请求 */
  $.ajax({
    type: 'post',
    url:
      `http://192.168.1.6:9007/prod-api/modbusWrite/api/writeModbus?modbusType=` +
      item +
      `&setValue=` +
      tempvalue +
      `&startIndex=` +
      Startindex +
      `&setType=1`,
    data: ChineseName,
    dataType: 'json',
    async: false, //默认为true 异步
    success: function (data) {},
  })
}

function render() {
  renderer.render(scene, camera) //执行渲染操作
  labelRenderer.render(scene, camera) //CSS2D渲染
  requestAnimationFrame(render) //请求再次执行渲染函数render，渲染下一帧
}
/**自适应窗口 */
window.onresize = function () {
  camera.aspect = window.innerWidth / window.innerHeight
  camera.updateProjectionMatrix()

  renderer.setSize(window.innerWidth, window.innerHeight)
}

export { render, AddMeshIntoArr }
