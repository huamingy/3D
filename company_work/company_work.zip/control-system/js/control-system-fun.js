import * as THREE from '../../build/three.module.js'

import { CSS3DSprite } from '../../jsm/renderers/CSS3DRenderer.js'
import {
  scene,
  camera,
  renderer,
  labelRender,
  mixer,
  clock,
  controls,
  label2DRender,
} from './control-system-sence.js'

import Stats from '../../jsm/libs/stats.module.js'
import { CSS2DObject } from '../../jsm/renderers/CSS2DRenderer.js'
//2.0、性能插件  监听fps
var stats = new Stats()
document.body.appendChild(stats.dom)

function render() {
  stats.update()
  const delta = 5 * clock.getDelta()

  // scene.traverse(darkenNonBloomed)
  // bloomComposer.render()
  // scene.traverse(restoreMaterial)
  renderer.render(scene, camera)
  // finalComposer.render()

  requestAnimationFrame(render)
  labelRender.render(scene, camera)
  label2DRender.render(scene, camera)
}
export { render }
